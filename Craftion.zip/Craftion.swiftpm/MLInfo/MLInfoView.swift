import SwiftUI
import CoreML

struct MLInfoView: ViewController {
    @State private var userInput = ""
    @State var messages: [String] = [] {
        didSet {
            saveMessages()
        }
    }
    @State private var model: MLInfo?
    
    func makeView() -> some View {
        NavigationStack {
            
            Text("MLInfo est une IA. Elle peut présenter des erreurs.")
                .foregroundColor(Color.secondary)
                .font(.custom("Menlo", size: 15.0))
            
            ScrollView {
                ForEach(messages, id: \.self) { message in
                    Text(message)
                        .font(.custom("Menlo", size: 15.0))
                        .padding()
                        .background(message.hasPrefix("MLInfo: ") ? Color.green.opacity(0.2) : Color.blue.opacity(0.2))
                        .cornerRadius(10)
                        .frame(maxWidth: .infinity, alignment: message.hasPrefix("MLInfo: ") ? .leading : .trailing)
                }
            }
            
            HStack {
                TextField("Entrez votre message", text: $userInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .font(.custom("Menlo", size: 15.0))
                
                Button {
                    sendMessage()
                } label: {
                    Image(systemName: "paperplane.circle.fill")
                        .foregroundColor(Color.accentColor)
                        .font(.system(size: 50))
                }
                .disabled(userInput.isEmpty)
            }
        }
        .font(.custom("Menlo", size: 15.0))
        .padding()
        .onAppear {
            loadModel()
            loadMessages()
        }
    }
    
    var body: some View {
        makeView()
    }
    
    func loadModel() {
        guard let modelURL = Bundle.main.url(forResource: "MLInfo", withExtension: "mlmodel") else {
            print("❌ Impossible de trouver le modèle")
            return
        }
        
        do {
            let compiledURL = try MLModel.compileModel(at: modelURL)
            model = try MLInfo(contentsOf: compiledURL)
            print("✅ Modèle chargé correctement")
        } catch {
            print("❌ Erreur en chargeant ou compilant le modèle : \(error)")
        }
    }
    
    func sendMessage() {
        guard let model = model else {
            print("⚠️ Modèle non chargé")
            messages.append("<Système>: Erreur modèle non chargé")
            return
        }
        
        do {
            let input = MLInfoInput(text: userInput)
            let prediction = try model.prediction(input: input)
            print("🔍 Prédiction retournée : \(String(describing: prediction.label))")
            let response = convertLabels(prediction: prediction)
            
            messages.append("\(userInput)")
            messages.append("MLInfo: \(response)")
            userInput = ""
        } catch {
            print("❌ Erreur prédiction : \(error)")
            messages.append("<Système>: Impossible de prédire")
        }        
    }
    
    func convertLabels(prediction: MLInfoOutput) -> String {
        let label = prediction.label
        
        switch label {
        case "Greetings":
            return [
                "Salut, comment vas-tu ?",                
                "Bonjour ! Comment puis-je t'aider ?",
                "Hello, est-ce que ça va ?",
                "Bonjour, cher ami !"
            ].randomElement()!
        case "Craftion":
            return [
                "Craftion est une application qui permet de créer, gérer et utiliser des questions personnalisées pour faciliter l’apprentissage.",
                "Craftion, c'est une application géniale pour apprendre son vocabulaire ennuyeux de manière ludique.",
                "Craftion, c'est une application révolutionnaire pour apprendre son vocabulaire tout en restant amusant. As-tu d'autres questions ?",
                "Si tu souhaites apprendre du vocabulaire facilement, alors tu es à la bonne adresse ! Tu peux apprendre de manière innovante to vocabulaire ici !"
            ].randomElement()!
        case "Craftion_Ability":
            return [
                "Utiliser Craftion permet d’apprendre de manière interactive, de poser des questions et d’explorer des connaissances variées.",
                "Utiliser Craftion, c'est surtout rester actif lorsqu'on étudie son vocabulaire !",
                "Mmh, Je pense que la meilleure raison d'utiliser Craftion, c'est que tu peux non seulement rester actif quand tu étudies ton vocabulaire, mais qu'en plus c'est super interactif !",
                "Honêtement, je pense qu'utiliser Craftion permet d'étudier son vocabulaire de manière simple et rapide."
            ].randomElement()!
        case "Add_Question":
            return [
                "Pour ajouter une question, il suffit de remplir les champs requis dans le formulaire avec la question et sa réponse.",
                "Si tu veux ajouter une ou plusieurs questions, c'est très simple: tu dois juste définir la question, puis la réponse. Autrement, tu ne saura pas l'ajouter.",
                "Ajouter une question, c'est très simple: dans l'onglet principal de l'app, tu pourras voir un bouton bleu “Ajouter une question”. Clique dessus et tu verras un formulaire. Ensuite, complète le formulaire et ta question s'affichera dans voir les questions.",
                "Dans “Ajouter une question”, un formulaire te sera présenté. Indique la question, puis la réponse(exemple: question: 1+1, réponse: 2), clique sur “Ajouter”, et c'est fini ! C'est si simple que moi-même je pourrais le faire. Attends, non, vu que je n'ai pas de contrôle sur l'app:(..."
            ].randomElement()!
        case "Buttons":
            return [
                "L’application dispose de plusieurs boutons comme “Ajouter”, “Supprimer”, “Modifier” et d’autres pour naviguer facilement.",
                "Cette application te propose plusieurs boutons comme “Ajouter”, “Supprimer”, “Modifier” et bien d'autres pour une expérience plus immersive.",
                "Craftion te propose divers bouton & widgets, tels que: Ajouter une question, Jouer les questions, Voir les questions, etc...",
                "Mon application te propose les boutons principaux(Ajouter une question, Jouer les questions et Voir les questions), mais également d'autres, comme: Exemple de questions, Commandes, Réglages et informations."
            ].randomElement()!
        case "View_Questions":
            return [
                "Le bouton “Voir les questions” permet d’afficher, consulter et modifier toutes les questions déjà créées.",
                "Ce serait très dommage si tu ne savais point lire tes questions déjà enregistrées. Heureusement, le bouton “Voir les questions” résout le problème !",
                "Bon, imaginons que tu te trompes au moment d'écrire une nouvelle question. Tu l'ajoutes, mais comment la supprimer ? Eh bien, dans Voir les questions, tu pourras y retrouver ta question(en question ? Bon, ça va, je me tais).",
                "Même si Voir les questions n'est pas le centre de l'app, tu verras avec l'expérience qu'il est primordial. C'est la liste de tes questions actuelles."
            ].randomElement()!
        case "Questions_Types":
            return [
                "Tu peux ajouter plusieurs types de questions comme des questions de vocabulaire, de culture générale, de mathématiques et bien d’autres encore.",
                "Les types de questions sont en réalité très variés. Tu peux mettre en réalité ce que tu souhaite, mais personnellement, je te recommande au moins des réponses courtes.",
                "Les types de questions sont nombreux, mais en voici quelques un: le vocabulaire, les petits calculs, etc...",
                "Il n'y a pas réellement de questions à respecter, mais pour ma part, je ferais des petites réponses."
            ].randomElement()!
        case "Bye":
            return [
                "À la prochaine !",
                "Au revoir !",
                "Salut !",
                "Si tu as d'autres questions, n'hésite pas !"
            ].randomElement()!
        default:
            print("⚠️ Étiquette inconnue : \(label)")
            return [
                "Je n'ai pas compris votre demande.",
                "Je te demande pardon, mais peux-tu reformuler ta requête ?",
                "Peux-tu me réexpliquer ta demande ?",
                "Je m'excuse, mais bien que mon cousin ChatGPT soit plus puissant que moi, il fonctionne sur un système radicalement différent, le modèle GPT, alors que je fonctionne sur un modèle assez restreint. Si tu peux te reformuler, je pourrais peut-être mieux t'aider."
            ].randomElement()!
        }
    }
    
    // MARK: - Sauvegarde et chargement des messages
    
    func saveMessages() {
        let defaults = UserDefaults.standard
        defaults.set(messages, forKey: "SavedMessages")
    }
    
    func loadMessages() {
        let defaults = UserDefaults.standard
        if let savedMessages = defaults.object(forKey: "SavedMessages") as? [String] {
            messages = savedMessages
        }
    }
}
