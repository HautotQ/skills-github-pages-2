import SwiftUI

struct EditQuestionView: ViewController {
    @ObservedObject var questionStore: QuestionStore
    let question: Question
    @State private var editedQuestion: String
    @State private var editedAnswer: String
    
    init(questionStore: QuestionStore, question: Question) {
        self.questionStore = questionStore
        self.question = question
        _editedQuestion = State(initialValue: question.query)
        _editedAnswer = State(initialValue: question.answer)
    }
    
    
    func makeView() -> some View {
        VStack {
            Form{
                TextField("Question", text: $editedQuestion)
                    .padding()
                    .autocorrectionDisabled()
                    .font(.custom("Menlo", size: 15.0))
                TextField("Réponse", text: $editedAnswer)
                    .padding()
                    .autocorrectionDisabled()
                    .font(.custom("Menlo", size: 15.0))
            }
        }
        .toolbar {
            Button("Enregistrer") {
                if let index = questionStore.questions.firstIndex(where: { $0.id == question.id }) {
                    questionStore.questions[index].query = editedQuestion
                    questionStore.questions[index].answer = editedAnswer
                }
                print("modifications enregistrées!")
            }
            .font(.custom("Menlo", size: 15.0))
            .foregroundColor(.white)
            .frame(width: 350, height: 50)
            .background(.red)
            .clipShape(Capsule())
            .padding(.top, 8)
        }
        .font(.custom("Menlo", size: 15.0))
        .navigationBarTitle("Modifier la question")
    }
    var body: some View {
        makeView()
    }
}
