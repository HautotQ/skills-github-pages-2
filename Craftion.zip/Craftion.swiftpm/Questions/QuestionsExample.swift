import SwiftUI

struct QuestionsExample: ViewController {
    @EnvironmentObject var listQuestionsExample: ListQuestionsExample  
    
    func makeView() -> some View {
        VStack {
            if listQuestionsExample.currentList.isEmpty {
                Text("Pas de questions disponibles.")
                    .foregroundColor(.gray)
            } else {
                List {
                    ForEach(listQuestionsExample.currentList) { question in
                        LabeledContent(question.query) {
                            Text(question.answer)
                        }
                    }
                }
            }
        }
        .font(.custom("Menlo", size: 15.0))
        .navigationTitle("Exemple de questions")
    }
    var body: some View {
        makeView()
    }
}

