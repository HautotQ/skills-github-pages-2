import SwiftUI
import AVFoundation

struct PlayQuestionsView: ViewController {
    @ObservedObject var questionStore: QuestionStore
    @Binding var currentQuestion: Question?
    @Binding var showingAnswer: Bool
    @State private var userAnswer = ""
    @State private var remainingQuestions: [Question] = []
    @State private var allQuestionsAnsweredOnce = false
    @State private var showAlert = false
    @State private var incorrectQuestions: [Question] = []
    @State private var shouldReaskIncorrectQuestion = false
    public var questionsChecked = 0
    @State private var audioPlayers: [String: AVAudioPlayer] = [:] // Dictionnaire pour gérer les lecteurs audio
    @State private var score = 0
    @State private var incorrectQuestionSet: Set<Question> = []
//    @State private var showEndView = false
    
    var answerComplete: Bool {
        if userAnswer != "" {
            return false
        } else {
            return true
        }
    }
    
    var remainingQuestionsCount: Int {
        return remainingQuestions.count
    }    
    var progress: Double {
        let totalQuestions = questionStore.questions.count
        let answeredQuestionsCount = totalQuestions - remainingQuestions.count
        return totalQuestions == Int(0.0) ? 0.0 : Double(answeredQuestionsCount) / Double(totalQuestions)
    }
    
    func makeView() -> some View {
        Group {
            
            if allQuestionsAnsweredOnce {
                EndView(score: score)
                
            } else {
                VStack {
                    if let question = currentQuestion {
                        VStack(spacing: 0) {
                            Text("questions restantes: \(remainingQuestionsCount)")
                            Gauge(value: progress, in: 0...1) {
                                Text("Progression actuelle")
                            } currentValueLabel: {
                                Text("\(Int(progress * 100))%")
                            }
                            .gaugeStyle(.linearCapacity)
                            Text(question.query)
                                .padding()
                                .fontWeight(.bold)
                                .font(.custom("Menlo", size: 25.0))
                            TextField("Réponse", text: $userAnswer)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocorrectionDisabled()
                                .font(.custom("Menlo", size: 15.0))
                            Form {}
                        }
                        
                    }
                }
                .toolbar {
                    if let question = currentQuestion {
                        Button(action: {
                            checkAnswer(for: question)
                        }) {
                            Text(answerComplete ? "Je ne connais pas la réponse" : "Vérifier la réponse")
                                .font(.custom("Menlo", size: 15.0))
                                .foregroundColor(.white)
                                .frame(width: 350, height: 50)
                                .background(.red)
                                .clipShape(Capsule())
                                .padding(.top, 8)
                        }
                        .padding()
                    }
                }
                .navigationBarTitle("Jouer les questions")
                .onAppear {
//                    self.progress = 0.0
                    remainingQuestions = questionStore.questions.shuffled()
                    if remainingQuestions.count == questionStore.questions.count {
                        currentQuestion = remainingQuestions.first
                    }
                    askNextQuestion()
                    playSound("Theme", soundExtension: "caf", loop: true, isActive: SettingsView.isSoundOn == true)
                }
                .onDisappear {
                    // Re-add incorrect questions to the end
                    if !incorrectQuestions.isEmpty {
                        remainingQuestions.append(contentsOf: incorrectQuestions)
                        incorrectQuestions.removeAll()
                    }
                }
                .alert(isPresented: $showAlert) {
                    if answerComplete == false {
                        Alert(
                            title: Text("Mauvaise réponse"),
                            message: Text("La réponse correcte est : \(currentQuestion?.answer ?? "")"),
                            dismissButton: .default(Text("OK"))
                        )
                    } else {
                        Alert(
                            title: Text("La réponse correcte est : \(currentQuestion?.answer ?? "")"),
                            dismissButton: .default(Text("OK"))
                        )                        
                    }
                }
            }
        }
        .font(.custom("Menlo", size: 15.0))
        .navigationTitle("Jouer les questions")
    }
    
    var body: some View {
        makeView()
    }
    private func askNextQuestion() {
        if shouldReaskIncorrectQuestion {
            shouldReaskIncorrectQuestion = false
            if !incorrectQuestions.isEmpty {
                remainingQuestions.append(contentsOf: incorrectQuestions.shuffled())
                incorrectQuestions.removeAll()
            }
            
            if let nextIncorrectQuestion = remainingQuestions.first {
                currentQuestion = nextIncorrectQuestion
                showingAnswer = false
                userAnswer = ""
                remainingQuestions.removeFirst()
                return
            }
        }
        
        guard let nextQuestion = remainingQuestions.first else {
            allQuestionsAnsweredOnce = true
            return
        }
        
        currentQuestion = nextQuestion
        showingAnswer = false
        userAnswer = ""
        remainingQuestions.removeFirst()
    }
    private func checkAnswer(for question: Question) {
        if userAnswer.lowercased() == question.answer.lowercased() {
            if !incorrectQuestionSet.contains(question) {
                score += 1  // Incrémenter le score seulement si la question n’a jamais été mal répondue
            }
            askNextQuestion()
            playSound("levelup", isActive: SettingsView.isSoundOn == true)
        } else if userAnswer.lowercased() == "" {
            showAlert = true
            incorrectQuestions.append(question)
            incorrectQuestionSet.insert(question)  // Ajouter au set des questions mal répondues
            shouldReaskIncorrectQuestion = true
            playSound("gameover", isActive: SettingsView.isSoundOn == true)
        } else if userAnswer.isApproximatelyEqual(to: question.answer, threshold: 25) && SettingsView.coolMode == true {
            if !incorrectQuestionSet.contains(question) {
                score += 1  // Incrémenter seulement si jamais mal répondu
            }
            askNextQuestion()
            playSound("levelup", isActive: SettingsView.isSoundOn == true)
        } else {
            showAlert = true
            incorrectQuestions.append(question)
            incorrectQuestionSet.insert(question)  // Ajouter au set des questions mal répondues
            shouldReaskIncorrectQuestion = true
            playSound("gameover", isActive: SettingsView.isSoundOn == true)
        }
    }
    func playSound(_ soundName: String, soundExtension: String = "mp3", loop: Bool = false, isActive: Bool = true) {
        guard isActive, let soundURL = Bundle.main.url(forResource: soundName, withExtension: soundExtension) else { return }
        
        do {
            // Créer un lecteur audio pour ce son ou récupérer l'existant
            if let existingPlayer = audioPlayers[soundName] {
                existingPlayer.stop() // Arrêter si déjà en cours pour redémarrer
            }
            
            let newPlayer = try AVAudioPlayer(contentsOf: soundURL)
            newPlayer.numberOfLoops = loop ? -1 : 0
            newPlayer.play()
            
            // Stocker le lecteur audio dans le dictionnaire
            audioPlayers[soundName] = newPlayer
        } catch {
            print("Erreur lors de la lecture du son : \(error.localizedDescription)")
        }
    }
}
