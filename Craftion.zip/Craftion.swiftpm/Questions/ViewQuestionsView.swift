import SwiftUI
import AVFoundation

struct ViewQuestionsView: ViewController {
    @ObservedObject var questionStore: QuestionStore
    @Binding var currentQuestion: Question?
    @Binding var showingAnswer: Bool
    @State private var isImporting: Bool = false
    @State private var isExporting: Bool = false
    @State private var sharedContent: String = "Contenu à partager"
    @State private var fileContent: String = ""
    @State private var importedText: String = ""
    @State private var deleteAllAlert: Bool = false
    @State private var showAddQuestion = false
    @State var showEditQuestion = false
//    @State private var audioPlayer: AVAudioPlayer?
    @State private var audioPlayers: [String: AVAudioPlayer] = [:] // Dictionnaire pour gérer les lecteurs audio
    @State var alertItem: AlertItem?
    @State var textSearchBar: String = ""
    
    var filteredQuestions: [Question] {
        if textSearchBar.isEmpty {
            return questionStore.questions
        } else {
            return questionStore.questions.filter { $0.query.localizedCaseInsensitiveContains(textSearchBar) }
        }
    }
    
    func makeView() -> some View {
        VStack {
            List {
                ForEach(filteredQuestions.indices, id: \.self) { index in
                    NavigationLink(destination: { 
                        EditQuestionView(
                            questionStore: questionStore,
                            question: questionStore.questions[index]
                        )
                    }, label: { 
                        LabeledContent(questionStore.questions[index].query) {
                            Text(questionStore.questions[index].answer)                            
                        }
                    })
                    .contextMenu {
                        Button(action: {
                            questionStore.questions.remove(at: index)
                        }) {
                            Text("Supprimer")
                                .font(.custom("Menlo", size: 15.0))
                            Image(systemName: "trash")
                        }
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                        Button(role: .destructive) {
                            questionStore.questions.remove(at: index)
                        } label: {
                            Label("Supprimer", systemImage: "trash")
                        }
                    }
                }
                .onDelete { indexSet in
                    questionStore.questions.remove(atOffsets: indexSet)
                    if let current = currentQuestion, indexSet.contains(questionStore.questions.firstIndex(where: { $0.id == current.id }) ?? -1) {
                        currentQuestion = nil
                        showingAnswer = false
                    }
                }
            }
            .searchable(text: $textSearchBar)
            .font(.custom("Menlo", size: 15.0))
            .navigationBarTitle("Voir les questions")
            .toolbar {
                Button {
                    showAddQuestion = true
                } label: {
                    Text("Ajouter une question")
                        .font(.custom("Menlo", size: 15.0))
                        .foregroundColor(.white)
                        .frame(width: 270, height: 50)
                        .background(.blue)
                        .clipShape(Capsule())
                        .padding(.top, 8)
                }
//                EditButton()
//                    .font(.custom("Menlo", size: 15.0))
                Menu(content: { 
                    Button("Tout supprimer") {
                        deleteAllAlert = true 
                    }
                    .font(.custom("Menlo", size: 15.0))
                    .colorMultiply(Color.red)
                    Button(action: {
                        importText()
                    }) {
                        Text("importer une liste de questions")
                            .font(.custom("Menlo", size: 15.0))
                        Image(systemName: "square.and.arrow.down")
                    }
                    Button(action: {
                        isExporting = true
                    }) {
                        Text("exporter une liste de questions")     
                            .font(.custom("Menlo", size: 15.0))
                        Image(systemName: "square.and.arrow.up")
                    }
                }, 
                     label: {
                    Image(systemName: "plus.app")                    
                }
                )
                .font(.custom("Menlo", size: 15.0))
            }
            .sheet(isPresented: $isExporting) {
                let formattedQuestions = questionStore.questions.map { "\($0.query)\n\($0.answer)" }.joined(separator: "\n\n")
                ShareSheet(activityItems: [formattedQuestions])
            }
            .sheet(isPresented: $showAddQuestion) {
                AddQuestionView(questionStore: questionStore)
            }
            
            .alert(isPresented: $deleteAllAlert) {
                Alert(
                    title: 
                        Text("Supprimer toutes les réponses?")
                        .font(.custom("Menlo", size: 20.0)),
                    message: Text("Toutes les questions seront perdues si vous ne les avez pas enregistrées.").font(.custom("Menlo", size: 15.0)),
                    primaryButton: .cancel(),
                    secondaryButton: .destructive(Text("J'ai compris").font(.custom("Menlo", size: 15.0)), action: { 
                        deleteAll()
                    })                    
                )
            }
        }
        .font(.custom("Menlo", size: 15.0))
    }
    var body: some View {
        makeView()
    }
    func deleteAll() {
        questionStore.questions.removeAll()
        playSound("bomb", isActive: SettingsView.isSoundOn == true)
    }
    func importText() {
        let documentPicker = DocumentPicker { [self] url in
            do {
                let fileContents = try String(contentsOf: url)
                let parsedQuestions = parseQuestions(from: fileContents)
                DispatchQueue.main.async {
                    questionStore.questions.removeAll()
                    questionStore.questions.append(contentsOf: parsedQuestions)
                }
            } catch {
                print("Erreur lors de la lecture du fichier : \(error.localizedDescription)")
            }
        }
        UIApplication.shared.windows.first?.rootViewController?.present(UIHostingController(rootView: documentPicker), animated: true, completion: nil)
    }
    func parseQuestions(from fileContents: String) -> [Question] {
        var parsedQuestions: [Question] = []
        
        // Split le contenu du fichier en fonction de la structure réelle
        let questionComponents = fileContents.components(separatedBy: "\n\n")
        
        for component in questionComponents {
            // Supposons que chaque composant contient une question et une réponse séparées par un saut de ligne
            let questionAndAnswer = component.components(separatedBy: "\n")
            
            // Assurez-vous qu'il y a au moins une question et une réponse
            if questionAndAnswer.count >= 2 {
                let question = questionAndAnswer[0]
                let answer = questionAndAnswer[1]
                
                // Créez un objet Question avec les valeurs extraites
                let parsedQuestion = Question(query: question, answer: answer)
                
                // Ajoutez la question à l'array
                parsedQuestions.append(parsedQuestion)
            }
        }
        
        return parsedQuestions
    }
    func playSound(_ soundName: String, soundExtension: String = "mp3", loop: Bool = false, isActive: Bool = true) {
        guard isActive, let soundURL = Bundle.main.url(forResource: soundName, withExtension: soundExtension) else { return }
        
        do {
            // Créer un lecteur audio pour ce son ou récupérer l'existant
            if let existingPlayer = audioPlayers[soundName] {
                existingPlayer.stop() // Arrêter si déjà en cours pour redémarrer
            }
            
            let newPlayer = try AVAudioPlayer(contentsOf: soundURL)
            newPlayer.numberOfLoops = loop ? -1 : 0
            newPlayer.play()
            
            // Stocker le lecteur audio dans le dictionnaire
            audioPlayers[soundName] = newPlayer
        } catch {
            print("Erreur lors de la lecture du son : \(error.localizedDescription)")
        }
    }
}
