import SwiftUI

struct AddQuestionView: ViewController {
    @Environment(\.dismiss) private var dismiss
    @StateObject var questionStore: QuestionStore
    @State private var question = ""
    @State private var answer = ""
    
    func makeView() -> some View {
        VStack {
            Text("Ajouter une question")
                .font(.largeTitle)
                .bold()
            Form{
                TextField("Question", text: $question)
                    .padding()
                    .autocorrectionDisabled()
                TextField("Réponse", text: $answer)
                    .padding()
                    .autocorrectionDisabled()
                Button("Ajouter") {
                    add()
                    print("Question enregistrée!")
                }
                .disabled(question.isEmpty || answer.isEmpty)
                .padding()
                Button("Fermer") {
                    dismiss()
                }
            }
            .navigationBarTitle("Ajouter une question")
        }
        .font(.custom("Menlo", size: 15.0))
    }
    
    var body: some View {
        makeView()
    }
    func add() {
        let newQuestion = Question(
            query: question,
            answer: answer
        )
        questionStore.questions.append(newQuestion)
        question = ""
        answer = ""
    }
}
