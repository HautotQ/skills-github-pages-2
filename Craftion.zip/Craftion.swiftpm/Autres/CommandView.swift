import SwiftUI

struct CommandView: ViewController {
    @EnvironmentObject var listQuestionsExample: ListQuestionsExample
    @ObservedObject var questionStore = QuestionStore()
    @State private var widgetText: String = UserDefaults.standard.string(forKey: "WidgetState") ?? "Seul Link peut vaincre Ganon"
    @State private var chatText: String = ""
    @State private var chatMessages: [String] = UserDefaults.standard.array(forKey: "ChatHistory") as? [String] ?? []
    func makeView() -> some View {
        HStack {
            VStack(alignment: .leading) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(chatMessages, id: \.self) { message in
                            Text(message)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
                .padding()
                
                HStack {
                    TextField("Entrez un message", text: $chatText)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(minHeight: 40)
                    
                    Button {
                        processMessage()
                    } label: {
                        Image(systemName: "arrow.up.circle.fill")
                            .foregroundColor(.red)
                    }
                    .padding(.horizontal)
                }
                .padding()
            }
        }
        .font(.custom("Menlo", size: 15.0))
        .onAppear(perform: loadState)
    }
    var body: some View {
        makeView()
    }
    
    private func saveChatHistory() {
        UserDefaults.standard.set(chatMessages, forKey: "ChatHistory")
    }
    
    private func processMessage() {
        let trimmedMessage = chatText.trimmingCharacters(in: .whitespacesAndNewlines)        
        chatMessages.append(trimmedMessage)
        saveChatHistory() // Sauvegarde automatique après ajout
        chatText = ""
        
        // Gestion des commandes
        switch trimmedMessage {
        case "/say hello":
            chatMessages.append("Bonjour !")
        case "/say bye":
            chatMessages.append("Au revoir !")
        case "/clear":
            chatMessages.removeAll()
        case "/set @QuestionsExample maths":
            listQuestionsExample.setQuestionsExample(withID: "maths")
            chatMessages.append("Commande réussie. Vous pouvez trouver les exemples de questions dans l'onglet Exemple de questions.")
        case "/set @QuestionsExample culture":
            listQuestionsExample.setQuestionsExample(withID: "culture")
            chatMessages.append("Commande réussie. Vous pouvez trouver les exemples de questions dans l'onglet Exemple de questions.")
        case "/give culture":
            questionStore.setQuestionStore(withID: "culture")
            chatMessages.append("Commande réussie. Vous pouvez trouver les questions dans l'onglet Voir les questions, après avoir redémarré l'app.")
        case "/give maths":
            questionStore.setQuestionStore(withID: "maths")
            chatMessages.append("Commande réussie. Vous pouvez trouver les questions dans l'onglet Voir les questions, après avoir redémarré l'app.")
        case "/clear_chat":
            let mlInfo = MLInfoView()
            mlInfo.messages.removeAll()
            chatMessages.append("Commande réussie. Le chat de MLInfo a été effacé.")
        case "/clear @QuestionsExample":
            listQuestionsExample.setQuestionsExample(withID: "empty")
            chatMessages.append("Exemples de Questions nettoyé")
        case "/46":
            crash_46()
        case "/toggle sound":
            SettingsView.isSoundOn.toggle()
            chatMessages.append("Le son a été \(SettingsView.isSoundOn == true ? "activé" : "désactivé").")
        case "/toggle coolMode":
            SettingsView.coolMode.toggle()
            chatMessages.append("Le mode Cool a été \(SettingsView.coolMode == true ? "activé" : "désactivé").")
        default:
            chatMessages.append("<Système>: erreur dans la syntaxe : \(trimmedMessage)")
        }
    }
    
    private func crash_46() {
        listQuestionsExample.setQuestionsExample(withID: "46")
        questionStore.setQuestionStore(withID: "46")
        fatalError()
    }
    private func clearChatHistory() {
        chatMessages.removeAll()
        UserDefaults.standard.set(chatMessages, forKey: "ChatHistory")
    }
    
    private func saveState() {
        UserDefaults.standard.set(chatMessages, forKey: "ChatHistory")
        UserDefaults.standard.set(widgetText, forKey: "WidgetState")
    }
    
    private func loadState() {
        chatMessages = UserDefaults.standard.array(forKey: "ChatHistory") as? [String] ?? []
        widgetText = UserDefaults.standard.string(forKey: "WidgetState") ?? "Seul Link peut vaincre Ganon"
    }
}

