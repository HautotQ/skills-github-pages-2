import SwiftUI

struct CommandsList: View {
    
    var body: some View {
        VStack {
            Form {
                LabeledContent("/say hello") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/say hello"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/say bye") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/say bye"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/clear") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/clear"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/set @QuestionsExample maths") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/set @QuestionsExample maths"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/set @QuestionsExample culture") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/set @QuestionsExample culture"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/give culture") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/give culture"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/give maths") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/give maths"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/clear_chat") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/clear_chat"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/clear @QuestionsExample") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/clear @QuestionsExample"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/toggle sound") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/toggle sound"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
                LabeledContent("/toggle coolMode") {
                    Button("Copier") {
                        UIPasteboard.general.string = "/say hello/toggle coolMode"
                    }
                    .buttonStyle(BorderedProminentButtonStyle())
                }
            }
        }
    }
}

#Preview {
    CommandsList()
}
