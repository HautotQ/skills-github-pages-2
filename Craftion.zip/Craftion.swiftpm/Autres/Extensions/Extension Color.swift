import SwiftUI

extension CraftionColor {
    static func random() -> CraftionColor {
        return CraftionColor(
            red: Double.random(in: 0...1),
            green: Double.random(in: 0...1),
            blue: Double.random(in: 0...1)
        )
    }
    static func gradient() -> [CraftionColor] {
        let gradients = [
            CraftionColor.random(),
            CraftionColor.random(),
            CraftionColor.random(),
            CraftionColor.random()
        ]
        return gradients
    }
}
