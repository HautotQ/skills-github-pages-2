import SwiftUI

extension CraftionString {
    func levenshteinDistance(to other: CraftionString) -> CraftionInt {
        let (a, b) = (CraftionArray(self.lowercased()), CraftionArray(other.lowercased()))
        let empty = [CraftionInt](repeating: 0, count: b.count + 1)
        var last = [CraftionInt](0...b.count)
        
        for (i, charA) in a.enumerated() {
            var cur = [i + 1] + empty.dropFirst()
            for (j, charB) in b.enumerated() {
                cur[j + 1] = charA == charB ? last[j] : Swift.min(last[j], last[j + 1], cur[j]) + 1
            }
            last = cur
        }
        return last.last ?? 0
    }
    
    func isApproximatelyEqual(to other: CraftionString, threshold: CraftionInt = 2) -> CraftionBool {
        return levenshteinDistance(to: other) <= threshold
    }
}
