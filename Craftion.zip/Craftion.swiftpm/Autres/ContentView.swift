import SwiftUI

struct ContentView: ViewController {
    @StateObject var questionStore = QuestionStore()
    @StateObject private var listQuestionsExample = ListQuestionsExample()    
    @State private var showingAnswer = false
    @State private var currentQuestion: Question?
    @State private var incorrectCurrentQuestion: Question?
    @State private var showAlert = false
    @State private var showAddQuestion = false
    
    var questionsCount: Int {
        return questionStore.questions.count
    }
    func makeView() -> some View {
        NavigationView {
            List {
                
                Section(content: { 
                    Button {
                        showAddQuestion = true
                    } label: {
                        Text("Ajouter une question")
                            .font(.custom("Menlo", size: 15.0))
                            .foregroundColor(.white)
                            .frame(width: 270, height: 50)
                            .background(.blue)
                            .clipShape(Capsule())
                            .padding(.top, 8)
                            .underline(pattern: .dash)
                    }
                    
                    NavigationLink(destination: PlayQuestionsView(questionStore: questionStore, currentQuestion: $currentQuestion, showingAnswer: $showingAnswer)) {
                        Text("Jouer les questions")
                            .font(.custom("Menlo", size: 15.0))
                            .underline()
                    }
                    .padding()
                    
                    NavigationLink(destination: { 
                        ViewQuestionsView(
                            questionStore: questionStore,
                            currentQuestion: $currentQuestion,
                            showingAnswer: $showingAnswer
                        )
                    }, label: { 
                        Text("Voir les questions")
                            .font(.custom("Menlo", size: 15.0))
                    })
                    .padding()
                    //                    .badge(questionsCount)
                    .underline()
                    //                    .colorMultiply(Color.green)
                    NavigationLink("exemples de questions"){
                        QuestionsExample()
                            .environmentObject(listQuestionsExample)
                    }
                    .underline()
                }, header: { 
                    Text("Craftion")
                        .colorMultiply(Color.secondary)
                })
                .font(.custom("Menlo", size: 15.0))
                Section(content: { 
                    NavigationLink("MLInfo") {
                        MLInfoView()
                    }
                    .underline()
                    NavigationLink("Commandes") {
                        CommandView()
                            .environmentObject(listQuestionsExample)
                    }
                    .underline()
                    NavigationLink("Liste des commandes") {
                        CommandsList()
                    }
                    .underline()
                    NavigationLink("Informations"){
                        Informations()
                    }
                    .underline()
                    .font(.custom("Menlo", size: 15.0))
                    NavigationLink("Réglages") {
                        SettingsView()
                    }
                    .underline()
                    .font(.custom("Menlo", size: 15.0))
                    NavigationLink("Crédits"){
                        VStack{
                            Text("Craftion")
                                .colorMultiply(.red)
                                .underline()
                            Text("Une idée de Tabarcraft")
                                .padding()
                            Text("Création: Tabarcraft")
                            Text("Programmation: Tabarcraft")
                            Text("Design: Tabarcraft")
                            Text("(ça peut paraître prétentieux mais j'ai fait cette app seul.)")
                                .padding()
                            Text("remerciements particuliers à toi, qui prend le temps de lire ces quelques lignes.")
                                .padding()
                            Link("Ma technique pour créer une app(une dinguerie)", destination: URL(string: "https://youtu.be/dQw4w9WgXcQ?si=FGPg6_p-et9R437b")!)
                                .colorInvert()
                        }
                        .font(.custom("Menlo", size: 15.0))
                    }
                    .underline()
                    .colorMultiply(.green)
                }, header: { 
                    Text("Autres")
                    .colorMultiply(Color.secondary)
                })
                .font(.custom("Menlo", size: 15.0))
            }
            .sheet(isPresented: $showAddQuestion) { 
                AddQuestionView(questionStore: questionStore)
                
            }
            .navigationBarTitle("Menu")
            ContentUnavailableView {
                Label("Pas d'onglet sélectionné", systemImage: "ipad.homebutton.badge.play")
                    .font(.custom("Menlo", size: 15.0))
            } description: {
                Text("Sélectionne un onglet et commence!")
                    .font(.custom("Menlo", size: 15.0))
            }
            .foregroundColor(Color.random())
        }
        .navigationBarBackButtonHidden(true)
    }
    var body: some View {
        makeView()
    }
}

