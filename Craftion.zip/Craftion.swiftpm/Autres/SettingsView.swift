import SwiftUI

struct SettingsView: ViewController {
    // Persistance de l'état du toggle avec @AppStorage
    @AppStorage("isSoundOn") static var isSoundOn: Bool = true
    @AppStorage("coolMode") static var coolMode: Bool = false
    
    func makeView() -> some View {
        Form {
            Section("Son & musique") {
                Toggle("Activer le son", isOn: toggleSound())
                    .padding()
                    .toggleStyle(SwitchToggleStyle(tint: .blue))                
            }
            Section("Craftion") {
                Toggle(isOn: SettingsView.$coolMode) {
                    Text("Activer le mode Cool(recommandé si vous étudiez de la théorie)")
                }
                    .padding()
                    .toggleStyle(SwitchToggleStyle(tint: .blue))
            }
        }
        .padding()
        .font(.custom("Menlo", size: 15.0))
    }
    var body: some View {
        makeView()
    }
    func toggleSound() -> Binding<Bool> {
        Binding(
            get: { SettingsView.isSoundOn },
            set: { newValue in
                SettingsView.isSoundOn = newValue
            }
        )
    }
    func toggleCoolMode() -> Binding<String> {
        Binding (
            get: { SettingsView.coolMode.description },
            set: { newValue in
                let string = String()
                SettingsView.coolMode = (string.levenshteinDistance(to: newValue) != 0)
            }            
        )

    }
}
