import SwiftUI

protocol Launcher: CraftionApp {
    associatedtype Launch: CraftionScene
    func launchApp() -> Launch
}
