import SwiftUI

protocol ViewController: CraftionView {
    associatedtype Controller: CraftionView
    func makeView() -> Controller
}
