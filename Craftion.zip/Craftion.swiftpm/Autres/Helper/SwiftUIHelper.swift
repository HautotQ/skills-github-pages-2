import SwiftUI

typealias CraftionScene = Scene
typealias CraftionWindowGroup = WindowGroup
typealias CraftionColor = Color
typealias CraftionString = String
typealias CraftionInt = Int
typealias CraftionArray = Array
typealias CraftionBool = Bool
typealias CraftionID = Identifiable
typealias CraftionCodable = Codable
typealias CraftionHashable = Hashable
typealias CraftionUUID = UUID
typealias CraftionObservableObject = ObservableObject
typealias CraftionEncoder = JSONEncoder
typealias CraftionDefaults = UserDefaults
typealias CraftionDecoder = JSONDecoder
typealias CraftionEncodable = Encodable
typealias CraftionDecodable = Decodable
typealias CraftionData = Data
typealias CraftionURL = URL
typealias CraftionFileManager = FileManager
typealias CraftionApp = App
typealias CraftionView = View

