import SwiftUI

struct EndView: ViewController {
    @StateObject private var questionStore = QuestionStore()
    @State var score: Int
    func makeView() -> some View {
        VStack {
            Text("Félicitations!")
                .font(.custom("Menlo", size: 15.0))
                .padding()
                .colorMultiply(.red)
                .underline()
            Text("Score final: \(score)/\(questionStore.questions.count)")
            Text("Vous pouvez toujours modifier, ajouter, jouer avec vos questions en cliquant sur L'onglet Craftion.")
        }
        .font(.custom("Menlo", size: 15.0))
    }
    var body: some View {
        makeView()
    }
}

