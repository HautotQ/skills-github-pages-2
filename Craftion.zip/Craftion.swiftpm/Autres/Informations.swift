import SwiftUI

struct Informations: ViewController {
    func makeView() -> some View {
        VStack {
            List {
                NavigationLink("Craftion") {
                    List {
                        NavigationLink("Ajouter une question") {
                            Text("Pour ajouter une question, Remplis La case Question de ta question dans le formulaire et fais de même pour la case réponse.")
                                .font(.custom("Menlo", size: 15.0))
                        }
                        .padding()
                        
                        NavigationLink("Jouer les questions") {
                            Text("Créer des questions, c'est bien, mais pouvoir jouer avec, c'est encore mieux! Au dessus, tu as ta question, en dessous tu as ton champ de texte pour ta réponse ainsi que le bouton vérifier. Si ta réponse est bonne, tu passes à la question suivante. Sinon tu restes jusqu'à avoir trouvé la bonne réponse. Au fait, une alerte s'affiche avec la bonne réponse lorsque tu as mauvais.")
                                .font(.custom("Menlo", size: 15.0))
                        }
                        .padding()
                        
                        NavigationLink("voir les questions") {
                            Text("Ce serait dommage que tu ne puisse pas voir, modifier ou supprimer tes questions. Eh bien le vouton voir les questions intervient! tu peux, comme je l'ai dit, tu peux voir, modifier et supprimer tes questions.")
                                .font(.custom("Menlo", size: 15.0))
                        }
                        .padding()
                        
                    }
                    .font(.custom("Menlo", size: 15.0))
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
                NavigationLink("exemples de questions") {
                    Text("L'onglet 'exemples de questions' est un onglet te proposant diverses qustions.Ce sont ici, bien entendu, des questions de culture générale mais je rappelle que l'application a comme but initial de pouvoir étudier du vocabulaire.")
                        .font(.custom("Menlo", size: 15.0))
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
                NavigationLink("MLInfo") {
                    Text("MLInfo est l'intelligence artificielle de cette application, n'hésite pas à le tester !")
                        .font(.custom("Menlo", size: 15.0))
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
                NavigationLink("Commandes") {
                    Text("L'onglet Commandes propose diverses commandes qui modifieront partiellement certains aspect de l'app, mais elles sont secrètes, donc amuse-toi à les découvrir !")
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
                NavigationLink("informations") {
                    Text("Je ne répondrais pas à cette question...")
                        .font(.custom("Menlo", size: 15.0))
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
                NavigationLink("Crédits") {
                    Text("Créer une appli prend beaucoup de temps, alors prends le temps de lire cet onglet.")
                        .font(.custom("Menlo", size: 15.0))
                }
                .font(.custom("Menlo", size: 15.0))
                .padding()
                
            }
        }
    }
    var body: some View {
        makeView()
    }
}
