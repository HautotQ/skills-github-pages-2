import SwiftUI

struct SearchBar: ViewController {
    @Binding var text: String
    
    func makeView() -> some View {
        VStack {
            TextField("Search...", text: $text)
                .font(.custom("Menlo", size: 15.0))
                .padding(8)
                .cornerRadius(8)
                .padding(.horizontal, 15)
        }
    }
    var body: some View {
        makeView()
    }
}
