import SwiftUI

class ListQuestionsExample: ObservableObject {
    @Published var currentList: [Question] = [] {
        didSet {
            saveCurrentList()
        }
    }
    
    let questionLists: [String: [Question]] = [
        "culture": [
            Question(query: "Quelle est la capitale de la France?", answer: "Paris"),
            Question(query: "Quelle est la couleur du ciel?", answer: "Bleu"),
            Question(query: "Qui a peint la Joconde?", answer: "Léonard de Vinci"),
            Question(query: "Quel est le plus grand océan du monde?", answer: "Le Pacifique"),
            Question(query: "Quel est le pays le plus peuplé au monde?", answer: "La Chine"),
            Question(query: "Quel est l'auteur de la pièce'Roméo et Juliette'?", answer: "William Shakespeare"),
            Question(query: "Qui a découvert la pénicilline?", answer: "Alexander Fleming"),
            Question(query: "Quelle est la plus longue rivière du monde?", answer: "L'Amazone"),
            Question(query: "Quel est le plus haut sommet du monde?", answer: "Le mont Everest"),
            Question(query: "Quelle est la capitale de l'Australie?", answer: "Canberra"),
            Question(query: "Quel est l'inventeur du téléphone?", answer: "Alexander Graham Bell"),
            Question(query: "Qui a écrit 'Les Misérables'?", answer: "Victor Hugo")
        ],
        "maths": [
            Question(query: "0+1", answer: "1"),
            Question(query: "1+1", answer: "2"),
            Question(query: "2+1", answer: "3"),
            Question(query: "3+1", answer: "4"),
            Question(query: "4+1", answer: "5"),
            Question(query: "5+1", answer: "6"),
            Question(query: "6+1", answer: "7"),
            Question(query: "7+1", answer: "8"),
            Question(query: "8+1", answer: "9"),
            Question(query: "9+1", answer: "10"),
            Question(query: "10+1", answer: "11"),
            Question(query: "11+1", answer: "12")
        ],
        "46": [
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46")
        ],
        "empty": []
    ]
    
    let questionStore = QuestionStore()
    
    init() {
        loadCurrentList()
    }
    
    func setList(to newList: [Question]) {
        currentList = newList
    }
    
    func setQuestionsExample(withID id: String) {
        if questionLists.keys.contains(id) {
            currentList = questionLists[id] ?? []
        } else {
            currentList = []  // Ou tu peux mettre une liste par défaut si l'ID n'est pas trouvé
        }
    }
    
    // Fonction de sauvegarde pour currentList
    private func saveCurrentList() {
        if let encodedList = try? JSONEncoder().encode(currentList) {
            UserDefaults.standard.set(encodedList, forKey: "SavedCurrentList")
            print("currentList sauvegardé avec \(currentList.count) questions.")
        }
    }
    
    // Fonction de chargement pour currentList
    private func loadCurrentList() {
        if let savedData = UserDefaults.standard.data(forKey: "SavedCurrentList"),
           let decodedList = try? JSONDecoder().decode([Question].self, from: savedData) {
            currentList = decodedList
            print("currentList chargé avec \(currentList.count) questions.")
        } else {
            print("Aucune liste sauvegardée trouvée.")
        }
    }
}

