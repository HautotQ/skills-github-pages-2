import SwiftUI

struct Question: CraftionID, CraftionCodable, CraftionHashable {
    var id = CraftionUUID()
    var query: CraftionString
    var answer: CraftionString
}
class QuestionStore: CraftionObservableObject {
    @Published var questions: [Question] = [] {
        didSet {
            saveQuestionList()
        }
    }
    
    let questionStoreLists: [CraftionString: [Question]] = [
        "culture": [
            Question(query: "Quelle est la capitale de la France?", answer: "Paris"),
            Question(query: "Quelle est la couleur du ciel?", answer: "Bleu"),
            Question(query: "Qui a peint la Joconde?", answer: "Léonard de Vinci"),
            Question(query: "Quel est le plus grand océan du monde?", answer: "Le Pacifique"),
            Question(query: "Quel est le pays le plus peuplé au monde?", answer: "La Chine"),
            Question(query: "Quel est l'auteur de la pièce'Roméo et Juliette'?", answer: "William Shakespeare"),
            Question(query: "Qui a découvert la pénicilline?", answer: "Alexander Fleming"),
            Question(query: "Quelle est la plus longue rivière du monde?", answer: "L'Amazone"),
            Question(query: "Quel est le plus haut sommet du monde?", answer: "Le mont Everest"),
            Question(query: "Quelle est la capitale de l'Australie?", answer: "Canberra"),
            Question(query: "Quel est l'inventeur du téléphone?", answer: "Alexander Graham Bell"),
            Question(query: "Qui a écrit 'Les Misérables'?", answer: "Victor Hugo")
        ],
        "maths": [
            Question(query: "0+1", answer: "1"),
            Question(query: "1+1", answer: "2"),
            Question(query: "2+1", answer: "3"),
            Question(query: "3+1", answer: "4"),
            Question(query: "4+1", answer: "5"),
            Question(query: "5+1", answer: "6"),
            Question(query: "6+1", answer: "7"),
            Question(query: "7+1", answer: "8"),
            Question(query: "8+1", answer: "9"),
            Question(query: "9+1", answer: "10"),
            Question(query: "10+1", answer: "11"),
            Question(query: "11+1", answer: "12")
        ],
        "46": [
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46"),
            Question(query: "CRASH", answer: "46")
        ],
        "empty": []
    ]
    
    private let dataManager = DataManager()
    
    init() {
        //        loadQuestions()
        loadQuestionList()
    }
    
    func setQuestionStore(withID id: CraftionString) {
        if let list = questionStoreLists[id] {
            questions = list
        } else {
            questions = []
        }
    }
    
    func saveQuestions() {
        dataManager.save(questions, fileName: "questions.txt")
    }
    
    func loadQuestions() {
        questions = dataManager.load(fileName: "questions.txt") ?? []
    }
    // Fonction de sauvegarde pour questions
    func saveQuestionList() {
        if let encodedList = try? CraftionEncoder().encode(questions) {
            CraftionDefaults.standard.set(encodedList, forKey: "SavedQuestionStore")
            print("questions sauvegardé avec \(questions.count) questions.")
        }
    }
    
    // Fonction de chargement pour questions
    func loadQuestionList() {
        if let savedData = CraftionDefaults.standard.data(forKey: "SavedQuestionStore"),
           let decodedList = try? CraftionDecoder().decode([Question].self, from: savedData) {
            questions = decodedList
            print("QuestionStore chargé avec \(questions.count) questions.")
        } else {
            print("Aucune liste sauvegardée trouvée.")
        }
    }
}



class DataManager {
    func save<T: CraftionEncodable>(_ data: T, fileName: CraftionString) {
        do {
            let url = getDocumentsDirectory().appendingPathComponent(fileName)
            let encoder = CraftionEncoder()
            let encodedData = try encoder.encode(data)
            try encodedData.write(to: url, options: .atomicWrite)
        } catch {
            print("Error saving data: \(error.localizedDescription)")
        }
    }
    
    func load<T: CraftionDecodable>(fileName: CraftionString) -> T? {
        do {
            let url = getDocumentsDirectory().appendingPathComponent(fileName)
            let data = try CraftionData(contentsOf: url)
            let decoder = CraftionDecoder()
            let decodedData = try decoder.decode(T.self, from: data)
            return decodedData
        } catch {
            print("Error loading data: \(error.localizedDescription)")
            return nil
        }
    }
    private func getDocumentsDirectory() -> CraftionURL {
        let paths = CraftionFileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
}

