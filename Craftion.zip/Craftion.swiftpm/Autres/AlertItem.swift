import SwiftUI

struct AlertItem: ViewController {
//    @Environment(\.dismiss) private var dismiss
    @State var title: Text?
    @State var message: Text?
    @State var cancelButton: Alert.Button?
    @State var destructiveButton: Alert.Button?
    
    var body: some View {
        makeView()
    }
    
    func makeView() -> some View {
        VStack {
            title
                .font(.custom("Menlo", size: 20.0))
                .bold()
            message
                .font(.custom("Menlo", size: 15.0))
        }
        .controlSize(.mini)
    }
}
