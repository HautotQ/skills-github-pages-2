import SwiftUI

struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let formattedQuestions = activityItems.reduce("") { (result, item) -> String in
            if let question = item as? String {
                return "\(result)\n\n\(question)"
            } else {
                return result
            }
        }
        let controller = UIActivityViewController(activityItems: [formattedQuestions], applicationActivities: nil)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
