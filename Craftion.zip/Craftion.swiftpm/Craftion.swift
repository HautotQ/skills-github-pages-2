import SwiftUI

@main
struct Craftion: Launcher {
    func launchApp() -> some CraftionScene {
        CraftionWindowGroup {
            ContentView()
        }
    }
    var body: some CraftionScene {
        launchApp()
    }
}
